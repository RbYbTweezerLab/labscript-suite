KeysightXSeries
===============

Overview
--------

This devices covers Keysight X-series oscilloscopes. It has been 
explicitely tested with 1000 and 3000 series 'scopes. Other series
should be simple to implement.

.. include:: _apidoc\naqslab_devices.KeysightXSeries.inc
