VISA
====

Overview
--------

This parent class establishes the standard communication protocol for 
all devices that use the VISA communication library. It relies on the
:std:doc:`PyVISA python wrapper <pyvisa:index>`.

.. include:: _apidoc\naqslab_devices.VISA.inc
