PulseBlasterESRPro300
=====================

Overview
--------

This is a thin subclass of the PulseBlaster_No_DDS labscript_device. It merely
configures the correct clock speed, digital output number, and clock resolution limits.

.. include:: _apidoc\naqslab_devices.PulseBlasterESRPro300.inc
