PulseBlaster_No_DDS_200
=======================

Overview
--------

This is a thin subclass of the PulseBlaster_No_DDS labscript_device. It merely
configures the correct clock speed and clock resolution limits for our custom 200 MHz clocked USB PulseBlaster board.

.. include:: _apidoc\naqslab_devices.PulseBlaster_No_DDS_200.inc
