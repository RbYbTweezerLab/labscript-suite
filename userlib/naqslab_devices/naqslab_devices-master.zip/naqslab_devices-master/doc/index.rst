.. naqslab_devices documentation master file, created by
   sphinx-quickstart on Fri Sep  6 14:11:37 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to naqslab_devices's documentation!
===========================================

This library is a collection of third-party devices for the labscript_suite experimental control system.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   usage
   devices
   doc_build


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

Credits
=======

:Authors:
	David Meyer
	Zac Castillo

:Licence: Simplified BSD License

:Version: |release|
